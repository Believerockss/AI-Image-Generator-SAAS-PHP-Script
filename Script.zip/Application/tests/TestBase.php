<?php

namespace Tests;

class TestBase
{
    use CreatesApplication;
}
