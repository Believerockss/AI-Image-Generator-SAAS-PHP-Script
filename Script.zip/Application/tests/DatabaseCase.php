<?php

namespace Tests;

class DatabaseCase
{
    use CreatesApplication;
}