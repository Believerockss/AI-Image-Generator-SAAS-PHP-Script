<?php

namespace Vironeer;

class System
{
    public const ALIAS = "imgurai";
    public const VERSION = "1.6";
    public const AUTHOR = "Vironeer";
    public const EMAIL = "support@vironeer.com";
    public const PROFILE = "https://codecanyon.net/user/vironeer";
    public const WEBSITE = "https://vironeer.com";
    public const LICENSE_URL = "http://license.vironeer.com/api/v1/license";
}