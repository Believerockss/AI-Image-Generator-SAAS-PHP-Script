require('../../global/js/shared')
require('./main')