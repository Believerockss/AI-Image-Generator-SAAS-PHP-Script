@extends('errors.layout')
@section('title', lang('Too Many Requests', 'errors'))
@section('code', '429')
@section('message', lang('Too Many Requests', 'errors'))
