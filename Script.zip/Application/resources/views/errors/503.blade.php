@extends('errors.layout')
@section('title', lang('Service Unavailable', 'errors'))
@section('code', '503')
@section('message', lang('Service Unavailable', 'errors'))
