@extends('errors.layout')
@section('title', lang('Page Expired', 'errors'))
@section('code', '419')
@section('message', lang('Page Expired', 'errors'))
