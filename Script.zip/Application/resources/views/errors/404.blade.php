@extends('errors.layout')
@section('title', lang('Page Not Found', 'errors'))
@section('code', '404')
@section('message', lang('Page Not Found', 'errors'))
