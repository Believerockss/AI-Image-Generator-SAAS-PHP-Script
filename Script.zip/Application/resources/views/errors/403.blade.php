@extends('errors.layout')
@section('title', lang('Forbidden', 'errors'))
@section('code', '403')
@section('message', lang('Forbidden', 'errors'))
