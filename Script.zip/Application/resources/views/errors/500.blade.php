@extends('errors.layout')
@section('title', lang('Server Error', 'errors'))
@section('code', '500')
@section('message', lang('Server Error', 'errors'))
