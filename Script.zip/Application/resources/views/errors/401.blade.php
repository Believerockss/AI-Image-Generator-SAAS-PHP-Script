@extends('errors.layout')
@section('title', lang('Unauthorized', 'errors'))
@section('code', '401')
@section('message', lang('Unauthorized', 'errors'))
