<link rel="stylesheet" href="{{ asset('assets/vendor/libs/bootstrap/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('assets/vendor/libs/fontawesome/v6.1.1/fontawesome.min.css') }}">
<link rel="stylesheet" href="{{ asset('assets/vendor/libs/toastr/toastr.min.css') }}">
<link rel="stylesheet" href="{{ asset('assets/vendor/libs/aos/aos.min.css') }}">
@stack('styles_libs')
<link rel="stylesheet" href="{{ asset('assets/extra/css/colors.css') }}">
<link rel="stylesheet" href="{{ asset('assets/extra/css/extra.css') }}">
@stack('styles')
<link rel="stylesheet" href="{{ asset('assets/extra/css/custom.css') }}">
