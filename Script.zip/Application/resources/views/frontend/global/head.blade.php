@include('frontend.configurations.metaTags')
<title>{{ pageTitle($__env) }}</title>
<link rel="icon" type="image/x-icon" href="{{ asset($settings->media->favicon) }}">
