<footer class="dash-footer">
    <div class="container-lg">
        <div class="dash-footer-copyright text-center">
            <p class="mb-0">&copy; <span data-year></span>
                {{ $settings->general->site_name }} - {{ lang('All rights reserved') }}.</p>
        </div>
    </div>
</footer>
