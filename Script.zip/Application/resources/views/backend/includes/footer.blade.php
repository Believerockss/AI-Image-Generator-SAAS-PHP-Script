<footer>
    <p class="mb-0"> &copy; <span data-year></span> {{ $settings->general->site_name }} -
        {{ admin_lang('All rights reserved.') }} | <span class="capitalize">{{ \Vironeer\System::ALIAS }}</span>
        v{{ \Vironeer\System::VERSION }}</p>
    <p class="mb-0 ms-auto">{{ admin_lang('Powered by Vironeer') }}</p>
</footer>
